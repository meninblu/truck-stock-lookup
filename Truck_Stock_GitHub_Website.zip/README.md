# Service Truck Stock Lookup

A mobile-friendly, offline-capable parts lookup for iPad. Shows **Truck Stock only**, with each part's **location first in red**.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Open the GitHub Pages URL on your iPad and use Safari's **Share → Add to Home Screen**.

No server, build process, or third-party dependencies are needed. Parts data is embedded in `index.html`. To update inventory, regenerate the file from the latest spreadsheet.

Quantities reflect the spreadsheet and are not live stock counts.
